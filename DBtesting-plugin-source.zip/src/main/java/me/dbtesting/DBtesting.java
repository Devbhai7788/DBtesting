package me.dbtesting;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashSet;
import java.util.Set;

public class DBtesting extends JavaPlugin implements Listener {

    private final Set<Player> godPlayers = new HashSet<>();

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("DBtesting enabled!");
    }

    @Override
    public void onDisable() {
        godPlayers.clear();
        getLogger().info("DBtesting disabled!");
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player player && godPlayers.contains(player)) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onHunger(FoodLevelChangeEvent e) {
        if (e.getEntity() instanceof Player player && godPlayers.contains(player)) {
            e.setCancelled(true);
            player.setFoodLevel(20);
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(ChatColor.RED + "This command can only be used by players.");
            return true;
        }

        Player player = (Player) sender;

        switch (cmd.getName().toLowerCase()) {

            case "god":
                if (!player.hasPermission("dbtesting.god")) {
                    player.sendMessage(ChatColor.RED + "You do not have permission to use this command.");
                    return true;
                }
                if (godPlayers.contains(player)) {
                    godPlayers.remove(player);
                    player.sendMessage(ChatColor.RED + "God mode disabled!");
                } else {
                    godPlayers.add(player);
                    player.sendMessage(ChatColor.GREEN + "God mode enabled!");
                }
                return true;

            case "heal":
                if (!player.hasPermission("dbtesting.heal")) {
                    player.sendMessage(ChatColor.RED + "You do not have permission to use this command.");
                    return true;
                }
                if (args.length != 1) {
                    player.sendMessage(ChatColor.YELLOW + "Usage: /heal <player>");
                    return true;
                }
                Player target = Bukkit.getPlayer(args[0]);
                if (target == null) {
                    player.sendMessage(ChatColor.RED + "Player not found.");
                    return true;
                }
                target.setHealth(target.getMaxHealth());
                target.setFoodLevel(20);
                target.setSaturation(20);
                target.getActivePotionEffects().forEach(effect -> target.removePotionEffect(effect.getType()));
                player.sendMessage(ChatColor.GREEN + "Healed " + target.getName());
                return true;

            case "warden":
            case "irongolem":
                String perm = "dbtesting." + cmd.getName().toLowerCase();
                if (!player.hasPermission(perm)) {
                    player.sendMessage(ChatColor.RED + "You do not have permission to use this command.");
                    return true;
                }
                if (args.length != 1) {
                    player.sendMessage(ChatColor.YELLOW + "Usage: /" + cmd.getName() + " <quantity>");
                    return true;
                }
                int amount;
                try {
                    amount = Integer.parseInt(args[0]);
                    if (amount <= 0) throw new NumberFormatException();
                } catch (NumberFormatException e) {
                    player.sendMessage(ChatColor.RED + "Quantity must be a positive number.");
                    return true;
                }

                EntityType type = cmd.getName().equalsIgnoreCase("warden") ? EntityType.WARDEN : EntityType.IRON_GOLEM;
                for (int i = 0; i < amount; i++) {
                    player.getWorld().spawnEntity(player.getLocation(), type);
                }
                player.sendMessage(ChatColor.GREEN + "Spawned " + amount + " " + type.name());
                return true;

            case "dbhelp":
                if (!player.hasPermission("dbtesting.help")) {
                    player.sendMessage(ChatColor.RED + "You do not have permission to use this command.");
                    return true;
                }
                player.sendMessage(ChatColor.GOLD + "---- DBtesting Help ----");
                player.sendMessage(ChatColor.YELLOW + "/god - Toggle god mode");
                player.sendMessage(ChatColor.YELLOW + "/heal <player> - Heal a player");
                player.sendMessage(ChatColor.YELLOW + "/warden <qty> - Spawn wardens");
                player.sendMessage(ChatColor.YELLOW + "/irongolem <qty> - Spawn iron golems");
                return true;
        }
        return false;
    }
}
